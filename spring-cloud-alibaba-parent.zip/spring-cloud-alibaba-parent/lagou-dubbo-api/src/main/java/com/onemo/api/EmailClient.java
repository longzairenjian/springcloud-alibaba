package com.onemo.api;


public interface EmailClient {

    Boolean send(String email, String code);
}

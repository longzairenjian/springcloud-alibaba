package com.onemo.api;


public interface CodeClient {

    /**
     * ⽣成验证码并发送到对应邮箱，成功true，失败false
     *
     * @param email 邮箱账号
     * @return true 成功 false 失败
     */
    Boolean create(String email);


    /**
     * 校验验证码是否正确，0正确1错误2超时
     *
     * @param email 邮箱账号
     * @param code  验证码
     */
    Integer validate(String email, String code);

}

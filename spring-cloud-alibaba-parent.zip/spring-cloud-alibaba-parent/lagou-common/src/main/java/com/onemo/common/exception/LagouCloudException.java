package com.onemo.common.exception;


public class LagouCloudException extends RuntimeException{

    private String code;

    private final String errorMsg;

    public LagouCloudException(String message) {
        super(message);
        this.errorMsg = message;
    }

    public LagouCloudException(String code, String errorMsg) {
        super(errorMsg);
        this.code = code;
        this.errorMsg = errorMsg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getErrorMsg() {
        return errorMsg;
    }
}

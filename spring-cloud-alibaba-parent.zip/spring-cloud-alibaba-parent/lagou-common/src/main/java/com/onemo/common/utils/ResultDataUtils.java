package com.onemo.common.utils;

import com.onemo.common.exception.LagouCloudException;
import com.onemo.common.module.ResultData;
import org.springframework.util.StringUtils;

import java.util.Objects;

public class ResultDataUtils {

    private static final String DEFAULT_CODE = "200";
    private static final String DEFAULT_MESSAGE = "响应成功";

    private static final String DEFAULT_ERROR_CODE = "500";
    private static final String DEFAULT_ERROR_MESSAGE = "服务异常";


    public static <T> ResultData<T> create(T t) {
        return create(DEFAULT_CODE, DEFAULT_MESSAGE, t);
    }


    /**
     * 构建一个返回错误消息的响应对象
     *
     * @param errorMsg 错误消息
     */
    public static ResultData<Void> createError(String errorMsg) {
        return create(DEFAULT_ERROR_CODE, errorMsg, null);
    }

    public static ResultData<Void> createError(String code, String errorMsg) {
        if (StringUtils.isEmpty(code)) {
            code = DEFAULT_ERROR_CODE;
        }
        return create(code, errorMsg, null);
    }

    /**
     * 构建一个返回错误消息的响应对象
     */
    public static ResultData<Void> createError() {
        return create(DEFAULT_ERROR_CODE, DEFAULT_ERROR_MESSAGE, null);
    }


    public static <T> T parse(ResultData<T> resultData) {
        if (Objects.isNull(resultData)) {
            throw new LagouCloudException("服务请求异常");
        }
        if (DEFAULT_CODE.equals(resultData.getCode())) {
            return resultData.getResult();
        }
        throw new LagouCloudException(StringUtils.isEmpty(resultData.getMessage()) ? "服务请求异常" : resultData.getMessage());
    }


    public static ResultData<String> createNeedLogin() {
        return create("403", "当前用户未登录，请登录后再操作", "操作失败，请先登录");
    }

    private static <T> ResultData<T> create(String code, String message, T t) {
        ResultData<T> resultData = new ResultData<>();
        resultData.setCode(code);
        resultData.setMessage(message);
        resultData.setResult(t);
        return resultData;
    }
}

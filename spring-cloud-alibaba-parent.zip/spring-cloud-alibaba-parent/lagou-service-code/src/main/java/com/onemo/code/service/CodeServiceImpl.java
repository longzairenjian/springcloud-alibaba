package com.onemo.code.service;

import com.onemo.api.CodeClient;
import com.onemo.api.EmailClient;
import com.onemo.common.exception.LagouCloudException;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.dubbo.config.annotation.Reference;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.data.redis.core.RedisTemplate;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

@Service
public class CodeServiceImpl implements CodeClient {

    @Resource
    private RedisTemplate<String, String> redisTemplate;

    @Reference
    private EmailClient emailClient;

    @Override
    public Boolean create(String email) {
        if (StringUtils.isBlank(email)) {
            throw new LagouCloudException("邮箱账号不能为空");
        }
        //生成一个随机验证码
        String random = RandomStringUtils.random(6, false, true);
        redisTemplate.opsForValue().set(email, random, 10, TimeUnit.MINUTES);
        //将验证码发送给邮件服务 交由邮件服务发送到用户邮箱中
        return emailClient.send(email, random);
    }

    @Override
    public Integer validate(String email, String code) {
        if (StringUtils.isBlank(email) || StringUtils.isBlank(code)) {
            throw new LagouCloudException("请求参数错误");
        }
        String randomCode = redisTemplate.opsForValue().get(email);
        if (StringUtils.isBlank(randomCode)) {
            //验证码已失效
            return 2;
        }
        if (randomCode.equals(code)) {
            //验证码正确且有效
            return 0;
        }
        //验证码错误
        return 1;
    }


}

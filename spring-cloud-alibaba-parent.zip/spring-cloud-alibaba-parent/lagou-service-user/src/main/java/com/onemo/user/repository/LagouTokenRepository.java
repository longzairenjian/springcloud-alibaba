package com.onemo.user.repository;

import com.onemo.user.entity.LagouToken;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LagouTokenRepository extends JpaRepository<LagouToken, Integer> {


    LagouToken findByAndEmail(String email);

    LagouToken findByAndToken(String token);

    LagouToken findByAndEmailAndPassword(String email, String password);
}
